#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){
   
    ofSetWindowTitle("openFrameworks example title");//设置窗口名称
    ofBackground(255, 255, 255);
    ofSetFrameRate(50);//设置帧率
}

//--------------------------------------------------------------
void ofApp::update(){

}

//--------------------------------------------------------------
//void ofApp::draw(){
//    int stepSize = 40;
//    ofColor myDrawCol;//设置颜色元素
//    //myDrawCol.set(200,255,200);
//    myDrawCol.setHsb(255,255,255);//使用hsb色度设置颜色(色度，饱和度，亮度，透明度)
//    ofSetColor(myDrawCol);
//
//    for(int y =0; y<ofGetHeight();y+=50){
//
//        for(int x =0; x<ofGetWidth(); x+=20){
//            //ofDrawCircle(ofRandom(ofGetWidth()), ofRandom(ofGetHeight()), 100);
//            myDrawCol.setHsb(ofMap(x, 0, ofGetWidth(), 0, 255),ofMap(y, 0, ofGetHeight(), 0, 255),ofMap(ofGetMouseY(), 0, ofGetHeight(), 0, 255),255);
//            ofSetColor(myDrawCol);
//            ofDrawCircle(ofRandom(ofGetWidth()), ofRandom(ofGetHeight()), ofRandom(80),ofRandom(50));
//        }
//    }
//
//    cout<< ofGetWidth()<<endl;//打印自定义窗口宽度
//
//}

void ofApp::draw(){
    int stepSize = 40;
    ofColor myDrawCol;
    myDrawCol.setHsb(255,255,255);
    ofSetColor(myDrawCol);
    
    for(int y =0; y<ofGetHeight();y+=50){
    
        for(int x =0; x<ofGetWidth(); x+=20){
            myDrawCol.setHsb(ofMap(x, 0, ofGetWidth(), 0, 255),ofMap(y, 0, ofGetHeight(), 0, 255),ofMap(ofGetMouseY(), 0, ofGetHeight(), 0, 255),255);
            ofSetColor(myDrawCol);
//            ofDrawTriangle(ofRandom(ofGetWidth()), ofRandom(ofGetHeight()),
//            ofRandom(ofGetWidth()), ofRandom(ofGetHeight()),
//            ofRandom(ofGetWidth()), ofRandom(ofGetHeight()));
            ofVec2f p1(ofRandom(ofGetWidth()), ofRandom(ofGetHeight()));
            ofVec2f p2(p1.x + ofRandom(-100, 100), p1.y + ofRandom(-100, 100));
            ofVec2f p3(p1.x + ofRandom(-100, 100), p1.y + ofRandom(-100, 100));

            ofDrawTriangle(p1, p2, p3); // 生成三角形

        }
    }
    
    cout<< ofGetWidth()<<endl;
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){
    if (key =='f'){
        ofToggleFullscreen();//f键全屏
    }
}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){
   
}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 

}
