

#ifndef myboid_hpp
#define myboid_hpp

#include <stdio.h>
#include "boid.h"


class myboid : public Boid {
public:
    myboid();
    void draw();
};

#endif
