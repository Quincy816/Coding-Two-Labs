#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){
    
    ofSetBackgroundColor(0);  // Set the initial background color to black
            serial.listDevices();     // List available serial devices
            serial.setup("/dev/cu.usbmodem1101", 9600);  // Set the serial device to the correct port and baud rate
            ledState = 0;             // Set the initial LED state to off
}

//--------------------------------------------------------------
void ofApp::update(){
    // Check for available serial data and process it as necessary
    while (serial.available()) { // Check for available serial data
                char data = serial.readByte(); // Read the data into a variable
                if (data == '0') {
                    ledState = 0; // Set the LED state to off
                } else if (data == '1') {
                    ledState = 255; // Set the LED state to on
                }
            }

    }

    // Read the state of the button
 


//--------------------------------------------------------------
void ofApp::draw(){
    ofBackground(ledState);
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){

}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){
    if (ledState == 0) {     // If the LED is off, turn it on
                serial.writeByte('1'); // Send a '1' to the Arduino to turn on the LED
                ledState = 255;       // Set the LED state to on
            } else {
                serial.writeByte('0'); // Send a '0' to the Arduino to turn off the LED
                ledState = 0;         // Set the LED state to off
            }
        }


//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 

}
